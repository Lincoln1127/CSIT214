const rows = 5; // Number of rows (same as number of columns for a square grid)
const columns = 5; // Number of columns (same as number of rows for a square grid)

function generateSeatNumber(row, column) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const rowLabel = alphabet[row];
    return `${rowLabel}${column + 1}`;
}

// Generate available seats based on rows and columns
const availableSeats = [];
for (let row = 0; row < rows; row++) {
    for (let column = 0; column < columns; column++) {
        const seatNumber = generateSeatNumber(row, column);
        availableSeats.push(seatNumber);
    }
}

const seatMap = document.getElementById("seatMap");

function createSeatElement(seatNumber) {
    const seat = document.createElement("div");
    seat.className = "seat";
    seat.textContent = seatNumber;
    seat.addEventListener("click", () => selectSeat(seatNumber)); // Call selectSeat function on click
    return seat;
}

let selectedSeats = []; // Array to store selected seats

function selectSeat(seatNumber) {
    // Check if the seat is already selected
    const index = selectedSeats.indexOf(seatNumber);
    if (index !== -1) {
        // If already selected, remove it from the array (deselect)
        selectedSeats.splice(index, 1);
    } else {
        // If not selected, add it to the array (select)
        selectedSeats.push(seatNumber);
    }

    // You can update the seat UI here to show selection/deselection visually
}

function populateSeatMap() {
    availableSeats.forEach(seatNumber => {
        const seat = createSeatElement(seatNumber);
        seatMap.appendChild(seat);
    });
}

// Populate seat map when the page loads
populateSeatMap();

const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
app.use(bodyParser.json());

const connection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'csit214',
    password: 'csit214',
    database: 'csit214'
});

app.post('/store_seat', (req, res) => {
    const selectedSeats = req.body.selectedSeats;

    // Insert selected seat data into the database
    selectedSeats.forEach(seatNumber => {
        const query = 'INSERT INTO seats (seat_number) VALUES (?)';
        connection.query(query, [seatNumber], (error, results, fields) => {
            if (error) {
                console.error('Error storing seat data:', error);
                res.status(500).json({ message: 'Error storing seat data' });
            }
        });
    });

    console.log('Seat data stored successfully!');
    res.status(200).json({ message: 'Seat data stored successfully' });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
